Run the following commands to get the code in place for each module:

1. `npm install`
1. `node setup.js`

Once the code is ready you can open each individual module folder in your editor to work with that particular sample.