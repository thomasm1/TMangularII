## Integrating Angular with Node.js RESTful Services 

This is code used in the `Integrating Angular with Node.js RESTful Services` course available
at [Pluralsight.com](https://www.pluralsight.com/courses/angular-nodejs-restful-services).

Requirements:

* MongoDB 3.2 or higher
* Node.js 6.10 or higher