

class CustomersController {

    constructor(router) {



    }

    

}

module.exports = CustomersController;