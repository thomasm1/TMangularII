See the "src" folder at the root level for the final source code.

Note that the latest version of the code has changed from HttpModule to
HttpClientModule. Angular 4.3+ is required to use HttpClientModule.