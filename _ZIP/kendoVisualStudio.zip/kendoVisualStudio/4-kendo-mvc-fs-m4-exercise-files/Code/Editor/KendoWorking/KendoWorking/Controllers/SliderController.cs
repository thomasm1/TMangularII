﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KendoWorking.Controllers
{
    public class SliderController : Controller
    {
        //
        // GET: /Slider/

        public ActionResult Index()
        {
            return View();
        }

    }
}
