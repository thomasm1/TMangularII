## Demo Project for AWS Developer: Serverless Architecture and Monitoring

This repository contains the demo project for the [AWS Developer: Serverless Architecture and Monitoring course on Pluralsight.com](http://www.pluralsight.com/courses/aws-developer-serverless-architecture-monitoring).

## Known Issues

None yet!

Found one? Please let me know by opening an [issue](https://github.com/ryanmurakami/trash-panda-buffet/issues)!

## License

All Images copyright Ryan Lewis

All Code under MIT license


