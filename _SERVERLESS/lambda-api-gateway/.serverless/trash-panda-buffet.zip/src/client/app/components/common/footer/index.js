import React, { Component } from 'react'

import styles from './styles.css'

export default class extends Component {
  render () {
    return (
      <div className={styles.footer}>
        <small>
          Copyright 2018 by Ryan H Lewis
        </small>
      </div>
    )
  }
}
