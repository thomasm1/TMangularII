angular.
  module('tmm').
  component('postList', {
    template:
    + '<ul>' +
    '<li ng-repeat="post in $ctrl.posts">' +
      '<span>{{post.did}}</span>' +
      '<p>{{post.title}}</p>' +
    '</li>' +
  '</ul>' +
    '<div id="{{post.did}}" class="blogDiv"> ' +
    '<hr />  '+
    '<a href="#top"><button>Top</button></a>  '+
    '<h4 class="title dailytech longtitle">OUR DAILY TECH:</h4>  '+
    '<h5 id="cat3" class="  subdailytech">{{post.cats3}}</h5> '+
    '<p id="author" class="  author">{{post.author}}</p>'+   
    '<h6  id="date" class="  chapternumber">{{post.date}}</h6>'+  
    '<h6  id="title"   class="dailytitle chapternumber"> '+

    '<p>Commentary Counter posts: {{$ctrl.posts.length}}</p>',
        
    controller: function bloggerAug() {



      this.blogpost13 =  `<p class="firstparagraph"> 
      </p>
      <p class="quote"> 
      <p > </p>.
      `;
      this.blogcite13 = `
      <p class="cite">1. <a href="https://www.sensorsmag.com/components/addressing-sensor-challenges-and-demands-for-future-servicing"   target="_blank">https://www.sensorsmag.com/components/addressing-sensor-challenges-and-demands-for-future-servicing
      </a>
      </p>
      `;
          blogpost12=  `<p class="firstparagraph"> 
          </p>
          <p class="quote"> <sup>1</sup>
          </p><br />
          <img src="dist/img/mechDegrade.jpg" width="350px" class="zoom" /><br />
          <p > </p>.
       `;
          this.blogcite12 = ` 
          <p class="cite">1. <a href="https://www.sensorsmag.com/components/addressing-sensor-challenges-and-demands-for-future-servicing"   target="_blank">https://www.sensorsmag.com/components/addressing-sensor-challenges-and-demands-for-future-servicing
          </a>
          </p>`
          ;   
           this.blogpost11 =  `<p class="firstparagraph"> 
          </p>
          <p class="quote"> <sup>1</sup>
          </p><br />
          <img src="dist/img/mechDegrade.jpg" width="350px" class="zoom" /><br />
          <p > </p>.
       `;
          this.blogcite11 = ` 
          <p class="cite">1. <a href="https://www.sensorsmag.com/components/addressing-sensor-challenges-and-demands-for-future-servicing"   target="_blank">https://www.sensorsmag.com/components/addressing-sensor-challenges-and-demands-for-future-servicing
          </a>
          </p>`
          ;
      
          this.blogpost10 =  `<p class="firstparagraph"> 
          </p>
          <p class="quote">Machines used to be serviced according to a plan, and late maintenance would mean a risk of production downtime. Today, process data from machines is used for predicting remaining service life. Especially critical parameters such as temperature, noise, and vibration are recorded to help determine the optimal operating state or even necessary maintenance times. This allows unnecessary wear to be avoided and possible faults and their causes to be detected early on. With the help of this monitoring, considerable optimization potential in terms of facility availability and effectiveness arises, bringing with it decisive advantages.
      
          The main element in this predictive maintenance (PM) is condition-based monitoring (CBM)
      
          Addressing Sensor Challenges and Demands for Future Servicing<sup>1</sup>
          </p><br />
          <img src="dist/img/mechDegrade.jpg" width="350px" class="zoom" /><br />
          <p > </p>.
       `;
          this.blogcite10 = ` 
          <p class="cite">1. <a href="https://www.sensorsmag.com/components/addressing-sensor-challenges-and-demands-for-future-servicing"   target="_blank">https://www.sensorsmag.com/components/addressing-sensor-challenges-and-demands-for-future-servicing
          </a>
          </p>`
          ;
           
          this.blogpost9 =  `<p class="firstparagraph"> 
          </p>
          <p class="quote">. Arrays of SQUIDs (superconducting quantum interference devices) are currently the most common magnetometer, while the SERF (spin exchange relaxation-free) magnetometer is being investigated for future machines.<sup>1</sup>
          </p><br />
          <img src="dist/img/mechDegrade.jpg" width="350px" class="zoom" /><br />
          <p > </p>.
       `;
          this.blogcite9 = ` https://www.xlstat.com/en/solutions/features/classification-and-regression-trees
          <p class="cite">1. <a href="https://www.xlstat.com/en/solutions/features/classification-and-regression-trees"   target="_blank">https://www.xlstat.com/en/solutions/features/classification-and-regression-trees
          </a>
          </p>`
          ;
           
          this.blogpost8 =  `<p class="firstparagraph">Classification and Regression (Decision) Trees are not just accurate, multipurpose and foundational to predictive machine learning algorithms (e.g. random forests, bayesian trees, bagging), but the trees' final product reveals the different rationale for the output. Printed onto a sheet   of paper, both statistical practitioner and the domain professional intuitively and heuristically understand practical use for an analysis. This July 2017 Cancer study exemplifies the utility of healthcare-based algorithms of analysis ... 
          </p>
          <p class="quote">The aim of this study was to develop and validate a clinical predictive model for 1-year mortality among patients with colon cancer who survive for at least 30 days after surgery.<br /><br />Random forest, genetic algorithms and classification and regression trees were combined in order to identify the variables and partition points that optimally classify patients by risk of mortality. The resulting decision tree was categorized into four risk categories. Split-sample and bootstrap validation were performed.<sup>1</sup>
          </p><br />
          <img src="dist/img/irisCART.jpg" width="350px" class="zoom" /><br />
          <p >And, now that sound methodology meets an increasingly user-friendly Machine Learning software toolset for wider practical applications, beginning firstly within healthcare technologies <i>and that second opinion!</i></p>.
       `;
          this.blogcite8 = `Image credits: https://www.xlstat.com/en/solutions/features/classification-and-regression-trees
          <p class="cite">1. <a href="https://www.dovepress.com/combining-statistical-techniques-to-predict-postsurgical-risk-of-1-yea-peer-reviewed-article-CLEP#"   target="_blank">https://www.dovepress.com/combining-statistical-techniques-to-predict-postsurgical-risk-of-1-yea-peer-reviewed-article-CLEP#
          </a>
          </p>`
          ;
          
          this.blogpost7 =  `<p class="firstparagraph">Predictive analytics  has slowly progressed in sophistication over the past 45 years, and the current nexus with powerful machine-learning tools changes the health game: </p>
          <p class="quote"> A report by ABI Research June 2018 report highlighted a significant rise in patient monitoring devices, including AI for home-based preventative healthcare and predictive analytics, which could save hospitals around $52bn by 2021.<br /><br />
      
          Accenture’s Digital Health Technology Vision 2018 report also claims that 85% of health executives in the US believe that every human will be directly impacted on a daily basis by an AI-based decision within the next three years.<br /><br />
          
          Utilising big data generated by clinical information and research can reveal clusters and patterns which can benefit all aspects of healthcare, leading patient care to become increasingly strategic.<sup>1</sup>  </p>
          <p>It should be noted that the long road paved by statistical theory has revolutionized the above-mentioned fields as much as it now powers the practical use of analytics:</p>
          <p class="quote">Originating in the statistical (e.g., Holland
            1986; Rosenbaum 2002; Rubin 2005, 2006) and
            econometrics literature (see Heckman 2000,
            2001, 2005; Heckman & Vytlacil 2007a,b;
            Manski 1995, 2007), the counterfactual,
            Rubin, or potential outcomes model of causality
            has, over the past three decades, become
            the standard conceptual tool to unify the notion
            of causality, to understand the identification
            problem at the heart of causal inference,
            and to assess the utility of alternative estimation
            techniques (Sobel 2005).<sup>2</sup></p>
            <p>So, the take-away here is that A.I. and <i>Machine-Learning Research could have never progressed so quickly if not for the settled scientic paradigm over sound analysis that rules out spurious variables, while properly weighting the conditions that matter.</i> Furthermore, the mistakes in algorithm design were made in the 1970's, 1980's, and 1990's--misleading mistakes--have been swept aside, providing much-tested and refined strategies. The medical field's case exemplifies this evolution:</p>
          <p class="quote">Randomized controlled trials are considered the gold
          standard for assessing the efficacy of medications, medical
          procedures, or clinical strategies. Nevertheless, particularly
          for research on the prevention of chronic disease, randomized
          trials are often infeasible because of their size, time,
          and budget requirements, as well as questionable generalizability
          or ethical constraints.<br /><br />
          On the other hand, nonexperimental studies of interventions
          have frequently been criticized because of their potential
          for selection bias. This concern reached a crescendo
          with the disparity in estimated effects of hormone replacement
          therapy from randomized trials and nonexperimental
          studies. This imbroglio highlighted the need to develop
          and apply improved methods to reduce bias in nonexperimental
          studies in which selection bias or confounding is
          likely to occur .<sup>3</sup></p>
          <p>So, nowadays we don't ask for a second opinion when we can ask for a trillion opinions narrowed down to one heck of a second opinion!</p>`;
          this.blogcite7  = `
          <p class="cite">1. <a href="https://www.healthcareglobal.com/technology/ai-seen-less-threat-and-welcomed-health-professionals-research-reveals"   target="_blank">https://www.healthcareglobal.com/technology/ai-seen-less-threat-and-welcomed-health-professionals-research-reveals
          </a>
          </p>
          <p class="cite">2. <a href="https://www.annualreviews.org/doi/abs/10.1146/annurev.soc.012809.102702"   target="_blank">https://www.annualreviews.org/doi/abs/10.1146/annurev.soc.012809.102702
          </a>
          </p>    <p class="cite">3. <a href="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1448214/"   target="_blank">https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1448214/
          </a>
          </p>`
          ;
          
          this.blogpost6 = `<p class="quote">  <i>[Intel's]  i9-8950HK processor is the first mobile Intel processor with six cores and 12 threads. It comes fully unlocked. It has the new Intel thermal Velocity Boost, which automatically increases clock frequency up to 200 MHz if the processor temperature is low enough and there's enough turbo power, giving a turbo frequency of up to 4.8 GHz.</i></p>
          <p class="quote" The i9-8950HK processor is the first mobile Intel processor with six cores and 12 threads. It comes fully unlocked. It has the new Intel thermal Velocity Boost, which automatically increases clock frequency up to 200 MHz if the processor temperature is low enough and there's enough turbo power, giving a turbo frequency of up to 4.8 GHz.</i>
          </p>
          <p class="firstparagraph"> Needs shape our inventions and our inventions shape our needs: With the brand new set of mobile computing requirements serve up utility for the i9.  Intel's advances pale in comparison, however, to GPU and newer computing trends. This theme arises time after time in my posts, but mathematics will rewrite the rules of performance . . .</p>
          <p class="quote">The 8th Gen processors incorporate Intel Octane memory, a smart and adaptable system accelerator for desktop and mobile platforms using SATA-based storage technology.<br /><br />
      
          Intel also has released a new Data Drive Acceleration feature that boosts a large secondary HDD hard drive.
          
          Together, Intel Octane and Data Drive Acceleration provide up to 4.7x the game loading speed and 1.7x faster media loading, Intel said.
           </p>
          <p class="quote">
          The actual task of processing AI is a very different process from standard computing or GPU processing, hence the perceived need for specialized chips. A x86 CPU can do AI, but it does a task in 12 steps when only three are required; a GPU in some cases can also be overkill.
          <br /><br />
          Generally, scientific computation is done in a deterministic fashion. You want to know two plus three equals five and calculate it to all of its decimal places—x86 and GPU do that just fine. But the nature of AI is to say 2.5 + 3.5 is observed to be six almost all of the time without actually running the calculation. What matters with artificial intelligence today is the pattern found in the data, not the deterministic calculation. 
          <br /><br />
      The result of this predictive problem solving is that AI calculations can be done with single precision calculations. So while CPUs and GPUs can both do it very well, they are in fact overkill for the task. A single-precision chip can do the work and do it in a much smaller, lower power footprint.</p>
      
      <p class="quote">Intel "can deliver on CPU functionality, which has dropped in performance, but still lags on GPUs and modems," noted Rob Enderle, principal analyst at the Enderle Group.
      
      "Much of the performance these days is gated by the modem and the GPU, not the CPU, which just isn't as importance as it once was," he told TechNewsWorld.
      
      Developers may not benefit much from the new processors, Enderle said, because "with IDF shut down, Intel's developer efforts are largely moot."
      </p> `;
      
          this.blogcite6 = ` 
          <p class="cite">1. <a href="https://www.technewsworld.com/story/85252.html"   target="_blank">https://www.technewsworld.com/story/85252.html
          </a>
          </p>
          
          <p class="cite">2. <a href="https://www.cnet.com/news/intel-core-i9-9900k-may-boost-to-5ghz/"   target="_blank">https://www.cnet.com/news/intel-core-i9-9900k-may-boost-to-5ghz/
          </a>
          </p>
           `;
          this.blogpost5 = `<p class="firstparagraph">Batteries optimized by machine learning is a feature in the latest version of Android OS, Pie. Some may roll theirs, but the only of desserts that share nameship with the great constant, pi. <i>Mystical 3-1-4 also features A.I.-empowered Textual Analysis, which opens to multiple new possibilities:</i></p>
          <p class="quote">The other new machine learning-powered feature is the smart text selection tool that recognizes the meaning of the text you selected and then allows you to suggest relevant actions like opening Google Maps or bringing up the share dialog for an address.<sup>1</sup></p>
          <p>Further, Android Pie's <i>Digital Wellness</i> features offer all the trending self-obedience features--not the least of which FitBit's guilt-inducing, and highly effective,<strong>walk prompts--already the bots are running my life and I obey!</p></strong>`;
          this.blogcite5 = ` 
          <p class="cite">1. <a href="https://techcrunch.com/2018/08/06/say-hello-to-android-9-pie/"   target="_blank">https://techcrunch.com/2018/08/06/say-hello-to-android-9-pie/
          </a>
          </p>
           `;
           this.blogpost4 =  `<p class="quote"><i>Bone is constantly turning over through a process in which cells called osteoclasts dig tunnels through bone, and then cells called osteoblasts re-pave those tunnels with new bone. Econs acknowledges that it sounds like an inefficient system, but it has to work this way because you obviously need to be able to use your bones while those repairs are taking place.</i><br /><br />
           --Michael Econ, physician and member of the American Society for Bone and Mineral Research   
           <p class="firstparagraph"><i>Bone loss in space can reach 5 to 10% over the course of a year, however the sure cure is Digital Responsibility, the trending fad of 2018, spans from the upcoming Android Pie's in-device digital behavioral tools across the spectrum to Fitbit, Youtube, and others' timed get-up-and-walk push notifications.       </p>  `;
           this.blogcite4 = `<p class="cite">1. <a href="https://tonic.vice.com/en_us/article/ne5zg8/this-is-the-effect-working-out-has-on-your-bones"   target="_blank">https://tonic.vice.com/en_us/article/ne5zg8/this-is-the-effect-working-out-has-on-your-bones
           </a>
           </p> 
           `;
        this.blogpost3 =  `<p class="quote"><i>Responsive experience with real-time inferencing. There are many tasks where speed matters. This includes interactive speech, visual search, and video recommendations. As AI models increase in accuracy and complexity, traditional CPUs can’t keep up, and the Tesla P4 GPUs can cut latency by an order of magnitude.<br /><br />
        Video decoding. The Tesla P4 has a dedicated hardware-accelerated decode engine that works in parallel with the GPU, enabling it to transcode and infer up to 35 HD video streams in real time. The integration of deep learning into video pipelines lets organizations offer smarter video services.<br /><br />
        The inferencing engine that the Tesla P4 uses is based on Nvidia’s Pascal architecture and is designed to increase the performance of servers running deep learning workloads. Google didn’t give a date for general availability other than saying it’s “coming soon” to its public cloud.</i></p>  
        <p class="firstparagraph">Toys, if they are offered as presents remain unconditional gifts, and yet the devotion they procure make for a reciprocal gift: Google's Developer Tools and little to no cost serve the same purpose as Microsoft's free provisions of Integrated Develepment Environments, i.e. VS Code and recent purchase of GitHub. The New Data Economy, applies as much to the developers' field as it does to consumers'. </p>  `;
        this.blogcite3 = `<p class="cite">1. <a href="https://www.cio.com/article/3293424/artificial-intelligence/more-artificial-intelligence-options-coming-to-google-cloud.html"   target="_blank">https://www.cio.com/article/3293424/artificial-intelligence/more-artificial-intelligence-options-coming-to-google-cloud.html
        </a>
        </p> 
        `;
        this.blogpost2  = `<p class="quote"><i>Google announced it is making Nvidia's Tesla P4 GPU available as a cloud service, enabling more businesses to get started with AI projects quicklyi><sup>1</sup></p>
        <p class="firstparagraph">API Services &agrave; la Google Cloud have become a new Hallmark--available for 12-month free trial--of <i>Google's ambitious  kit: Cloud IoT (Internet of Things) API, Cloud Genomics API, Cloud Machine Learning Engine API, among dozens of others.</i> Rivers of Kubernetes Data,Tensor-Processing-Unit Automotons for Oompah-Loompahs, and the ever-lasting flavor of chewing gum in the name of publicly available data for your tasting pleasure!   </p>`;
        this.blogcite2  = `<p class="cite">1. <a href="https://www.cio.com/article/3293424/artificial-intelligence/more-artificial-intelligence-options-coming-to-google-cloud.html"   target="_blank">https://www.cio.com/article/3293424/artificial-intelligence/more-artificial-intelligence-options-coming-to-google-cloud.html
        </a>
        </p>`; 
      
         
         this.blogpost1 = `<p class="quote"><i>In July, Blackrock — the world’s largest exchange-traded fund (ETF) — announced that it has launched a working group to assess the potential of investing in Bitcoin.  <br /><br />
          Blackrock’s move could be described as a preemptive strike to avoid missing the crypto bus. Goldman Sachs is making headway with cryptocurrency involvement and Blackrock is following suit.</i><sup>1</sup></p>
          <p class="firstparagraph">
          <p class="quote">Fintech broke onto the scene as a disruptive force following the 2008 crisis, but the industry's influence on the broader financial services system is changing.
        
          The fintech industry no longer stands clearly apart from financial services proper, and is increasingly growing embedded in mainstream finance. We're now seeing the initial stages of this transformation.<br /><br />
          
          For instance, funding is growing more internationally distributed, and startups are making necessary adjustments to prove sustainability and secure a seat at the table. Most fintech segments in the ascendant a year ago have continued to rise and grow more valuable to the broader financial system. Meanwhile, several fintech categories have had to make adjustments to stay on top. New subsegments are also appearing on the scene — such as digital identity verification fintechs — as new opportunities for innovation are discovered. 
          <br /><br /> ... 
          The rising influence of fintechs is having a dramatic effect on incumbents, from banks to insurers to wealth managers, pushing them to respond proactively to stay relevant. Incumbents are reacting to changes wrought by fintechs on three key fronts: the front end, the back end, and in their core business operations. As such, incumbents and fintechs are converging on a digital middle ground.
        <br /><br />
          As this happens, the fintech industry is on the cusp of becoming an integral component of the broader financial services ecosystem. But it will likely first have to go through a complete credit cycle, and survive an economic downturn like the one that set the stage for its arrival in 2008, for this to happen.<sup>2</sup>
          </p>
          `;
          this.blogcite1 = `
          <p class="cite">1. <a href="https://cointelegraph.com/news/institutional-investors-and-fintech-will-wall-street-go-head-first-into-crypto"   target="_blank">https://cointelegraph.com/news/institutional-investors-and-fintech-will-wall-street-go-head-first-into-crypto
          </a>
          </p> 
          <p class="cite">2. <a href="https://www.businessinsider.com/8-3-2018-fintech-ecosystem-financial-technology-research-and-business-opportunities-2018-8?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+clusterstock+%28ClusterStock%29&r=US&IR=T&IR=T"   target="_blank">https://www.businessinsider.com/8-3-2018-fintech-ecosystem-financial-technology-research-and-business-opportunities-2018-8 
        </a>
        </p> 
          `; 


      this.posts = [
    /*
          {
            id: '14',
            did: '08-16-18',
            date: 'August 16, 2018',
            author: 'by Thomas Maestas',
            cat3: 'Sociology Tomorrow!',
            title: ' ',
            post: blogpost14,
            blogcite: blogcite14
          },
          */
          {
            id: '13',
            did: '08-15-18',
            date: 'August 15, 2018',
            author: 'by Thomas Maestas',
            cat3: 'Sociology Tomorrow!',
            title: 'Quantum Data',
            post: blogpost13,
            blogcite: blogcite13
          }, 
          {
            id: '12',
            did: '08-14-18',
            date: 'August 14, 2018',
            author: 'by Thomas Maestas',
            cat3: 'Musing Blockchain',
            title: ' ',
            post: blogpost12,
            blogcite: blogcite12
          },
       
          {
            id: '11',
            did: '08-12-18',
            date: 'August 12-13, 2018<br />Weekend',
            author: 'by Thomas Maestas',
            cat3: 'A.I.Now.',
            title: ' ',
            post: blogpost11,
            blogcite: blogcite11
          },
      
          {
            id: '10',
            did: '08-11-18',
            date: 'August 11, 2018',
            author: 'by Thomas Maestas',
            cat3: 'Web Dev Affairs',
            title: 'The Good Doctor, Part IV: Good Doctor, Heal Thyself!',
            post: blogpost10,
            blogcite: blogcite10
          },
          {
            id: '9',
            did: '08-10-18',
            date: 'August 10, 2018',
            author: 'by Thomas Maestas',
            cat3: 'A.I.Now.',
            title: 'The Good Doctor, Part III: Magneto Encephelop',
            post: blogpost9,
            blogcite: blogcite9
          }, 
          {
          id: '8',
             did: '08-09-18',
             date: 'August 9, 2018',
             author: 'by Thomas Maestas',
             cat3: 'Sociology Tomorrow!',
             title: 'The Good Doctor, Part II:  <br />About that Second Opinion . . . <br />',
             post: blogpost8,
             blogcite: blogcite8
           },
           {
             id: '7',
             did: '08-08-18',
             date: 'August 8, 2018',
             author: 'by Thomas Maestas',
             cat3: 'A.I.Now.',
             title: 'The Good Doctor, Part I: <br /> How A.I.-Driven Predictive Analytics Rewrites Healthcare',
             post: blogpost7,
             blogcite: blogcite7
           },
           {
             id: '6',
                 did: '08-07-18',
                 date: 'August 7, 2018',
                 author: 'by Thomas Maestas',
                 cat3: 'Web Dev Affairs',
                 title: 'New Math &amp; the Speed of Antiquation, a Case Study:<br />Mobile 8th Generation Intel',
                 post: blogpost6,
                 blogcite: blogcite6
               },
               {
                 id: '5',
             did: '08-06-18',
             date: 'August 6, 2018',
             author: 'by Thomas Maestas',
             cat3: 'Web Dev Affairs',
             title: 'Android Pi(e) Day',
             post: blogpost5,
             blogcite: blogcite5
           },
           {
             id: '4',
             did: '08-04-18',
             date: 'August 4-5, 2018<br />Weekend',
             author: 'by Thomas Maestas',
             cat3: 'Sociology Tomorrow!',
             title: 'The New Age of Digital Responsibility',
             post: blogpost4,
             blogcite: blogcite4
           },
           {
             id: '3',
             did: '08-03-18',
             date: 'August 3, 2018',
             author: 'by Thomas Maestas',
             cat3: ' ',
             title: 'Tour of Google\'s Chocolate Factory, Part II:<br />Glass Elevator into the Cloud',
             post: blogpost3,
             blogcite: blogcite3
           },
           {
             id: '2',
            did: '08-02-18',
             date: 'August 02, 2018<br />Weekend',
             author: 'by Thomas Maestas',
             cat3: 'Web Dev Affairs',
             title: 'Tour of Google\'s Chocolate Factory, Part II:<br />Google\'s Golden Ticket',
             post: blogpost2,
             blogcite: blogcite2
           },
           {
             id: '1', 
               did: '08-01-18',
               date: 'August 1, 2018',
               author: 'by Thomas Maestas',
               cat3: 'Musing Blockchain',
               title: 'Fintech Auchtung!',
               post: blogpost1,
               blogcite: blogcite1
             } 
      
        ];
    }
  });