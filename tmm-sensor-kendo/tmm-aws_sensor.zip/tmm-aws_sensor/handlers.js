module.exports = require('./lib/transfile.js')(__dirname + '/handlers/');
