Notes

Starting point
