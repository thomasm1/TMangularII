// angular.module('app').service('authStatus', function(auth) {
  
//   var status = {
//     loggedIn: false
//   }
  
//   auth.$onAuth(function(authObject) {
//     status.loggedIn = !!authObject;
//   });
  
//   return status;
  
// })